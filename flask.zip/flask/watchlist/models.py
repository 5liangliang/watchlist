from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from watchlist import db


class User(db.Model,UserMixin):   # 表名自动生成user                    # 模型类都要继承与db.Model
	id = db.Column(db.Integer, primary_key=True)            # 每个属性都要实例化。
	name = db.Column(db.String(20)) 
	username = db.Column(db.String(20)) # 用户名 
	password_hash = db.Column(db.String(128))  # 密码     # 可以在实例化的参数中写入 类型以及字段设置
	def set_password(self,password):
		self.password_hash = generate_password_hash(password)

	def validate_password(self,password):
		return check_password_hash(self.password_hash,password) # 返回布尔值



class Movie(db.Model,UserMixin):                                        # db.Integer 整型   db.String(size)字符串  db.Text长文本
	id = db.Column(db.Integer,primary_key = True)             # db.DateTime 时间日期  db.Float 浮点数  db.Boolean 布尔值
	title = db.Column(db.String(60))
	year = db.Column(db.String)
#  primary_key(布尔类型)  nullable 是否允许字段为空  index 是否设置索引 
#  unique 是否允许重复   default 默认值。通常为第二个参数