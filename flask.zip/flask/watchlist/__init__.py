import sys
import os
from flask import Flask

from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager



WIN = sys.platform.startswith('win')
# 在这里。 prefix 的意思是根目录文件
if WIN:     #如果是windows 系统，使用三个斜线
	prefix = 'sqlite:///'
else:
	prefix = 'sqlite:////'    


app = Flask(__name__)

app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev')

app.config['SQLALCHEMY_DATABASE_URI'] = prefix + os.path.join(os.path.dirname(app.root_path), os.getenv('DATABASE_FILE', 'data.db'))



app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False   # 关闭对模型修改的监控


db = SQLAlchemy(app)
login_manager = LoginManager(app)  # 实例化扩展类


@login_manager.user_loader
def load_user(user_id):
	from watchlist.models import User
	user = User.query.get(int(user_id))
	return user

login_manager.login_view = 'login'
# login_manager.login_view = '你的用户信息'


@app.context_processor
def inject_user():
# 函数名可以随意修改 
	from watchlist.models import User   
	user = User.query.first()
	return dict(user=user)  # 需要返回字典，等同于return {'user': user}


from watchlist import views, errors, commands