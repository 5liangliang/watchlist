
from flask import Flask, render_template
from flask import url_for,request,redirect,flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager,login_user,logout_user,login_required,current_user
from flask_login import UserMixin









# app.root_path 返回程序实例所在模块的路径，即项目根目录

# 在扩展类实例化前加载配置

































if __name__ =='__main__':
	app.run()