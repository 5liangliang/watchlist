from faker import faker

faker = Faker('zh_CN')  # 生成中文化数据

from faker.providers import BaseProvider


# 创建并继承，实现方法。
class MyProvider(BaseProvider):
	def foo(self):
		return 'bar'

# 添加到实例中
faker.add_provider(MyProvider)

# 调用
faker.foo()



